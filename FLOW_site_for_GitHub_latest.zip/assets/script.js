
const PRODUCTS = [
  {id:'retatrutide', name:'Retatrutide (10mg)', price:199.99, tags:['Metabolic'], img:'/assets/vials/retatrutide.svg', desc:'Multi-agonist research peptide that engages GLP-1, GIP and glucagon receptors; commonly investigated for effects on energy balance, weight management and glycemic control in controlled models.'},
  {id:'bpc157', name:'BPC-157 (5mg)', price:59.99, tags:['Recovery'], img:'/assets/vials/bpc157.svg', desc:'Pentadecapeptide analogue explored for support of connective-tissue signaling and gastric mucosa integrity; frequently used in in-vitro models of tissue repair.'},
  {id:'tb500', name:'TB-500 (5mg)', price:69.99, tags:['Recovery'], img:'/assets/vials/tb500.svg', desc:'Thymosin-β4 fragment studied for roles in cell migration, angiogenesis and modulation of inflammatory pathways within laboratory research settings.'},
  {id:'bpc_tb_blend', name:'BPC-157 + TB-500 Blend (10mg)', price:119.99, tags:['Recovery'], img:'/assets/vials/bpc_tb_blend.svg', desc:'Synergistic research blend that combines BPC-157 and TB-500 to enable multifactorial study designs related to soft-tissue recovery and remodeling.'},
  {id:'melanotan', name:'Melanotan II (10mg)', price:39.99, tags:['Pigmentation'], img:'/assets/vials/melanotan.svg', desc:'Synthetic analogue of α-MSH investigated for melanogenesis pathways and photobiology research.'},
  {id:'igf1', name:'IGF-1 LR3 (1mg)', price:149.99, tags:['Performance'], img:'/assets/vials/igf1.svg', desc:'Long-acting insulin-like growth factor analogue commonly used in vitro to study anabolic signaling and hypertrophy-related pathways.'},
  {id:'motsc', name:'MOTS-c (10mg)', price:129.99, tags:['Metabolic'], img:'/assets/vials/motsc.svg', desc:'Mitochondrial-derived peptide examined for influences on metabolic regulation, AMPK-linked exercise-mimetic signaling and cellular stress responses in model systems.'},
  {id:'semax', name:'Semax (10mg)', price:79.99, tags:['Cognitive'], img:'/assets/vials/semax.svg', desc:'Heptapeptide researched for neurotrophic and neuroprotective effects, including modulation of BDNF expression and synaptic plasticity in preclinical settings.'},
  {id:'bacwater', name:'Bacteriostatic Water (30ml)', price:9.99, tags:['Lab Supply'], img:'/assets/vials/bacwater.svg', desc:'Sterile water with 0.9% benzyl alcohol for laboratory reconstitution and handling of lyophilized materials.'},
  {id:'klow', name:'KLOW-80 Blend (8mg)', price:129.99, tags:['Recovery'], img:'/assets/vials/klow.svg', desc:'Composite research blend inspired by GHK-Cu, BPC-157, TB-500 and KPV to support multi-pathway studies of tissue repair and epithelial recovery.'},
  {id:'ghkcu', name:'GHK-Cu (10mg)', price:59.99, tags:['Skin'], img:'/assets/vials/ghkcu.svg', desc:'Copper-binding tripeptide used in vitro to investigate collagen support, dermal remodeling and wound-healing biology.'}
];

function money(v){return '$' + v.toFixed(2);}
function getCart(){try{return JSON.parse(localStorage.getItem('flow_cart')||'[]')}catch(e){return []}}
function setCart(c){localStorage.setItem('flow_cart', JSON.stringify(c)); renderCartPill();}
function addToCart(id){const cart=getCart(); const item=cart.find(i=>i.id===id); if(item){item.qty+=1;} else {cart.push({id,qty:1});} setCart(cart); alert('Added to cart');}
function removeFromCart(id){setCart(getCart().filter(i=>i.id!==id)); renderCartPage();}
function changeQty(id,delta){const cart=getCart(); const item=cart.find(i=>i.id===id); if(!item) return; item.qty=Math.max(1,item.qty+delta); setCart(cart); renderCartPage();}
function renderCartPill(){const pill=document.querySelector('#cart-pill'); if(!pill) return; const count=getCart().reduce((a,b)=>a+b.qty,0); pill.textContent = count>0? ('Cart • '+count): 'Cart';}
function productCard(p){const tags=(p.tags||[]).map(t=>`<span class="badge">${t}</span>`).join(''); return `<div class="product-card card">
  <div class="thumb"><img src='${p.img}' alt='${p.name}'/></div>
  <div class="body"><div class="kicker">${tags}</div><div style="font-weight:800">${p.name}</div><div class="price">${money(p.price)}</div>
    <div style="display:flex;gap:8px;margin-top:6px">
      <button onclick="addToCart('${p.id}')">Add to Cart</button>
      <a class="btn secondary" href="/pages/product.html?id=${p.id}">Details</a>
    </div></div></div>`;}
function renderFeatured(){const el=document.querySelector('#featured'); if(!el) return; el.innerHTML = PRODUCTS.slice(0,8).map(productCard).join('');}
function renderShop(){const el=document.querySelector('#shop-grid'); if(!el) return; el.innerHTML = PRODUCTS.map(productCard).join('');}
function qs(k){return new URLSearchParams(location.search).get(k)}
function renderProduct(){const id=qs('id'); const p=PRODUCTS.find(x=>x.id===id)||PRODUCTS[0];
  document.querySelector('#p-name').textContent=p.name; const imgEl=document.querySelector('#p-img'); if(imgEl) imgEl.src=p.img;
  document.querySelector('#p-price').textContent=money(p.price); document.querySelector('#p-desc').textContent=p.desc+' This product is provided for research and educational purposes only.';
  document.querySelector('#add-btn').onclick=()=>addToCart(p.id);}
function lineItemRow(item){const p=PRODUCTS.find(x=>x.id===item.id); const subtotal=p.price*item.qty; return `<tr><td>${p.name}</td>
  <td><div style="display:flex;gap:8px;align-items:center">
    <button class="btn secondary" onclick="changeQty('${item.id}',-1)">-</button>
    <div>${item.qty}</div>
    <button class="btn secondary" onclick="changeQty('${item.id}',1)">+</button></div></td>
  <td>${money(p.price)}</td><td>${money(subtotal)}</td><td><a href="#" onclick="removeFromCart('${item.id}')">Remove</a></td></tr>`;}
function renderCartPage(){const tbody=document.querySelector('#cart-body'); if(!tbody) return; const cart=getCart();
  if(cart.length===0){document.querySelector('#cart-empty').style.display='block'; document.querySelector('#cart-table').style.display='none'; document.querySelector('#checkout-cta').style.display='none'; return;}
  document.querySelector('#cart-empty').style.display='none'; document.querySelector('#cart-table').style.display='table'; document.querySelector('#checkout-cta').style.display='flex';
  tbody.innerHTML = cart.map(lineItemRow).join(''); const total = cart.reduce((a,b)=>{const p=PRODUCTS.find(x=>x.id===b.id); return a + p.price*b.qty;},0); document.querySelector('#cart-total').textContent=money(total);}
function saveCheckout(){const method=document.querySelector('input[name=paymethod]:checked')?.value||'card'; const email=document.querySelector('#email').value; const name=document.querySelector('#name').value; const address=document.querySelector('#address').value; localStorage.setItem('flow_checkout', JSON.stringify({method,email,name,address})); location.href='thanks.html';}
function renderThanks(){const data=JSON.parse(localStorage.getItem('flow_checkout')||'{}'); const el=document.querySelector('#thanks'); if(!el) return;
  el.innerHTML=`<div class="card" style="padding:20px"><h2>Thank you for your order${data.name? (', '+data.name):''}!</h2>
  <p>We have recorded your order. ${data.method==='bank' ? 'Please complete your <strong>bank transfer</strong> using the details below and include your order email as reference.' : 'Payment will be processed securely.'}</p>
  ${data.method==='bank' ? '<div class="notice"><strong>Bank Transfer Details</strong><br>Account Name: FLOW Wellness Pty Ltd<br>BSB: 062-000<br>Account: 12345678<br>Reference: your email</div>': ''}
  <p class="mini">Note: This is a front-end demo. No real payment was processed.</p></div>`; localStorage.removeItem('flow_cart'); renderCartPill();}
document.addEventListener('DOMContentLoaded', ()=>{renderFeatured(); renderShop(); renderProduct(); renderCartPill(); renderCartPage(); renderThanks();});
